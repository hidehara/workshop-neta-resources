#import requests

from PIL import Image

def lambda_handler(event, context):
    print(type(Image))
    #res = requests.get('http://httpbin.org/ip')

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
    #return res.json()
